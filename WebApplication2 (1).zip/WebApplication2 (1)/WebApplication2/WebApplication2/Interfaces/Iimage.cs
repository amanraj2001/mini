﻿//using System.Drawing;
using WebApplication2.Models;

namespace WebApplication2.Interfaces
{
    public interface Iimage:IGeneric<Image>
    {
    }
}
