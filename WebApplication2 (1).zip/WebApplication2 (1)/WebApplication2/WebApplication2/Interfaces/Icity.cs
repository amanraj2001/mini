﻿using WebApplication2.Models;

namespace WebApplication2.Interfaces
{
    public interface Icity:IGeneric<City>
    {

    }
}
