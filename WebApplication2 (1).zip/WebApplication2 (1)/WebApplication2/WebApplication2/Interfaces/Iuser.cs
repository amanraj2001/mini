﻿using Microsoft.AspNetCore.Mvc;
using WebApplication2.Dto;
using WebApplication2.Models;

namespace WebApplication2.Interfaces
{
    public interface Iuser:IGeneric<User>
    {

    }
}
