﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Web.Helpers;
using WebApplication2.Dto;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class User1controller : ControllerBase
    {
        private readonly MiniprojectContext _context;

        public User1controller(MiniprojectContext context)
        {
            _context = context;            
        }
        [HttpPost("register")]

        public async Task<IActionResult> register([FromBody] registerdto val)
        {
            string salt = Crypto.GenerateSalt();
            string password = val.Password + salt;
            string hashpassword = Crypto.HashPassword(password);
            User user = new User();
            user.Useremail = val.Useremail;
            user.Username = val.Username;
            user.UserpassHashed = hashpassword;
            user.UserpassSalt = salt;
             await _context.Users.AddAsync(user);
            await _context.SaveChangesAsync();
            return Ok(user);
        }

        [HttpPost("verify")]
        public async Task<IActionResult> authenticate([FromBody] registerdto val)
        {
            if(val == null)
            {
                return BadRequest("error");
            }
            var user =  _context.Users.FirstOrDefault(x=>x.Username== val.Username);
            if(user == null)
            {
                return NotFound();
            }
            if (verify(val, user.UserpassHashed, user.UserpassSalt))
            {
                return Ok("hello");
            }
            else
            {
                return BadRequest("error");
            }
        }


        public static bool  verify([FromBody] registerdto val,string hash,string salt)
        {
            val.Password = val.Password + salt;
            bool isverified = Crypto.VerifyHashedPassword(hash, val.Password);
            if (!isverified)
            {
                return isverified;
            }
            return isverified;
        }
    }
}
