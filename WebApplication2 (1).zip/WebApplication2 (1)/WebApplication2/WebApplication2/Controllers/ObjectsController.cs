﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using WebApplication2.Models;
//using Object = WebApplication2.Models.Object;

//namespace WebApplication2.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class ObjectsController : ControllerBase
//    {
//        private readonly MiniprojectContext _context;

//        public ObjectsController(MiniprojectContext context)
//        {
//            _context = context;
//        }

//        // GET: api/Objects
//        [HttpGet]
//        public IActionResult GetObjects(int id)
//        {
//            var data = from x in _context.Cars
//                       group x by x.Fueltype into newa
//                       select new
//                       {
//                           type = (from m in _context.Objects where m.ObjId == newa.Key select m.Name).First(),
//                           car = from a in newa select new
//                           {
//                               cardid = a.Carid,
//                               carName = a.Carbrand
//                           }
//                       };
                       
//            var data1 =  from x in _context.Cars
//                    where x.Fueltype == id
//                   select x;
          
//            return Ok(data);
//        }

//        // GET: api/Objects/5
//        [HttpGet("{id}")]
//        public async Task<ActionResult<Object>> GetObject(int id)
//        {
//          if (_context.Objects == null)
//          {
//              return NotFound();
//          }
//            var @object = await _context.Objects.FindAsync(id);

//            if (@object == null)
//            {
//                return NotFound();
//            }

//            return @object;
//        }

//        // PUT: api/Objects/5
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPut("{id}")]
//        public async Task<IActionResult> PutObject(int id, Object @object)
//        {
//            if (id != @object.ObjId)
//            {
//                return BadRequest();
//            }

//            _context.Entry(@object).State = EntityState.Modified;

//            try
//            {
//                await _context.SaveChangesAsync();
//            }
//            catch (DbUpdateConcurrencyException)
//            {
//                if (!ObjectExists(id))
//                {
//                    return NotFound();
//                }
//                else
//                {
//                    throw;
//                }
//            }

//            return NoContent();
//        }

//        // POST: api/Objects
//        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
//        [HttpPost]
//        public async Task<ActionResult<Object>> PostObject(Object @object)
//        {
//          if (_context.Objects == null)
//          {
//              return Problem("Entity set 'MiniprojectContext.Objects'  is null.");
//          }
//            _context.Objects.Add(@object);
//            await _context.SaveChangesAsync();

//            return CreatedAtAction("GetObject", new { id = @object.ObjId }, @object);
//        }

//        // DELETE: api/Objects/5
//        [HttpDelete("{id}")]
//        public async Task<IActionResult> DeleteObject(int id)
//        {
//            if (_context.Objects == null)
//            {
//                return NotFound();
//            }
//            var @object = await _context.Objects.FindAsync(id);
//            if (@object == null)
//            {
//                return NotFound();
//            }

//            _context.Objects.Remove(@object);
//            await _context.SaveChangesAsync();

//            return NoContent();
//        }

//        private bool ObjectExists(int id)
//        {
//            return (_context.Objects?.Any(e => e.ObjId == id)).GetValueOrDefault();
//        }
//    }
//}
