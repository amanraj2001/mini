﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Dto;
using WebApplication2.Interfaces;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarsController : ControllerBase
    {
        private readonly MiniprojectContext _context;
        private readonly Icity _city;

        public CarsController(MiniprojectContext context,Icity city)
        {
            _context = context;
            _city = city;
        }

        // GET: api/Cars
        [HttpGet]
        public IActionResult GetCars()
        {
            var carsdata = from x in _context.Cities
                           group x by x.Cityid into g
                           select new
                           {
                               type = g.Key,
                               xs = from a in g
                                    select new
                                    {
                                        a.Cars
                                    }


                           };
            return Ok(carsdata);
        }

        // GET: api/Cars/5
        [HttpPost("name")]
        public IActionResult GetCar( obj o)
        {
            //var data = from x in _context.Cars
            //           where x.Cartype==name
            //           select x;
            //   return Ok(data);
            //   l
            List<Car> cars = new List<Car>();
            IQueryable<Car> filterdata=null;
            foreach(var car in o.List) {
               filterdata = from x in _context.Cars
                                 where x.Carmodel == car
                                 select x;
               foreach(var i in  filterdata)
                {
                    cars.Add(i);
                }
            
            }
            return Ok(cars);
        }

        // PUT: api/Cars/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCar(int id, Car car)
        {
            if (id != car.Carid)
            {
                return BadRequest();
            }

            _context.Entry(car).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CarExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Cars
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Car>> PostCar(Car car)
        {
          if (_context.Cars == null)
          {
              return Problem("Entity set 'MiniprojectContext.Cars'  is null.");
          }
            _context.Cars.Add(car);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetCar", new { id = car.Carid }, car);
        }

        // DELETE: api/Cars/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCar(int id)
        {
            if (_context.Cars == null)
            {
                return NotFound();
            }
            var car = await _context.Cars.FindAsync(id);
            if (car == null)
            {
                return NotFound();
            }

            _context.Cars.Remove(car);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool CarExists(int id)
        {
            return (_context.Cars?.Any(e => e.Carid == id)).GetValueOrDefault();
        }
    }
}
