﻿using System;
using System.Collections.Generic;

namespace WebApplication2.Models;

public partial class Orderitem
{
    public int Orderitem1 { get; set; }

    public int? Carid { get; set; }

    public virtual Car? Car { get; set; }
}
