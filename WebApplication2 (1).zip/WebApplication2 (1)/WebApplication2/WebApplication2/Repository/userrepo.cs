﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Web.Helpers;
using WebApplication2.Dto;
using WebApplication2.Interfaces;
using WebApplication2.Models;

namespace WebApplication2.Repository
{
    public class userrepo : GenericRepo<User>, Iuser
    {
        public userrepo(MiniprojectContext context) : base(context)
        {
        }

        //public Task<User> register([FromBody] registerdto val)
        //{
        //    string salt = Crypto.GenerateSalt();
        //    string password = val.Password + salt;
        //    string hashpassword = Crypto.HashPassword(password);
        //    User user = new User();
        //    user.Useremail=val.Useremail;
        //    user.Username=val.Username;
        //    user.UserpassHashed=hashpassword;
        //    user.UserpassSalt=salt;
        //    //return 
        //    return 
            
        //}
    }
}
