﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Interfaces;
using WebApplication2.Models;

namespace WebApplication2.Repository
{
    public class GenericRepo<T> : IGeneric<T> where T : class
    {
        private readonly MiniprojectContext _context;
        private readonly DbSet<T> _dbset;

        public GenericRepo(MiniprojectContext context) { 
            _context =  context;
            _dbset = _context.Set<T>();
        }
        public IEnumerable<T> GetAll()
        {
            return _dbset.ToList();
        }
        //public IActionResult<T> get()
        //{
        //    return _dbset.ToList();
        //}
        public Task<T> Add(T entity)
        {
            throw new NotImplementedException();
        }

        public Task DeleteById(int id)
        {
            throw new NotImplementedException();
        }


        public Task<T> GetById(int id)
        {
            return null;
        }

        public Task<T> Update(int id, T entity)
        {
            throw new NotImplementedException();
        }
    }
}
