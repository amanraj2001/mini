﻿namespace WebApplication2.Dto
{
    public class obj
    {
        public List<string> List { get; set; }
    }
}
