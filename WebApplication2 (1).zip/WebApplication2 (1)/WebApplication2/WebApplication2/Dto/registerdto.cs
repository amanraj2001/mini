﻿namespace WebApplication2.Dto
{
    public class registerdto
    {
        public string? Username { get; set; }

        public string? Useremail { get; set; }
        public string? Password { get; set; }
    }
}
